package home_2;

/**
 * Created by swanta on 04.06.16.
 */
public class Pangolin extends Animal{

    public Pangolin (String name) {
        super(name);
        category = "Precise Pangolin";
        environment = "warm ground";
        favoriteActivity = "to eat worms";
        currentActivity = "hiding";
    }

}
