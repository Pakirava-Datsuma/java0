package home_2;

/**
 * Created by swanta on 04.06.16.
 */
public class Ocelot extends Animal {


    public Ocelot(String name) {
        super(name);
        category = "Oneiric Ocelot";
        environment = "green forest";
        favoriteActivity = "to sleep on tries";
        currentActivity = "waiting for ground mouse";

    }
}
