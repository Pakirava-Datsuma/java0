package home_2;

/**
 * Created by swanta on 04.06.16.
 */
public class Tahr extends Animal{
    public Tahr (String name) {
        super(name);
        category = "Trusty Tahr";
        environment = "Himalayas";
        favoriteActivity = "fight";
        currentActivity = "thinking";
    }
}
